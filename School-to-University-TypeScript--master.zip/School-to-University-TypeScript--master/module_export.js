
export function add(a: number, b: number){
    return a + b;
}
export function multiple(c: number, d: number){
     return c * d;
}


// if you want to make a group of constant values you can use const variable declaration 
//with enum


const enum world {pakistan =2, china=3 , russia};  
var country : world = world[3];  //this syntax not allowes in const enums
console.log(country);

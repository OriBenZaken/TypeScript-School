
// strong types syntax

let country: string = "china";
//country = 7;         // Error
console.log(country);
var num: number = 6;
//num = "ghjgjh";    // Error
console.log(num);

var bool: boolean = true;
//bool = "vfghg";   // Error
//bool = 9;          // Error
console.log(bool);

// type inference refers to automation detection of datatype

var a = "name";
var no = 7;
var boo = true;
